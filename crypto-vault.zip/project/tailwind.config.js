/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#070a12',
          900: '#0a0e17',
          850: '#0d1320',
          800: '#111827',
          700: '#1a2233',
          600: '#27324a',
          500: '#3a4866',
        },
        brand: {
          50: '#e6f9ff',
          100: '#ccf2ff',
          200: '#99e5ff',
          300: '#5fd2ff',
          400: '#2bb8f5',
          500: '#0a96db',
          600: '#0077b6',
          700: '#005f8c',
        },
        gold: {
          400: '#fbbf24',
          500: '#f59e0b',
        },
        ok: { 400: '#34d399', 500: '#10b981' },
        bad: { 400: '#f87171', 500: '#ef4444' },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['"Space Grotesk"', 'Inter', 'sans-serif'],
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(43,184,245,0.18), 0 8px 40px -12px rgba(10,150,219,0.45)',
        card: '0 1px 0 0 rgba(255,255,255,0.04) inset, 0 20px 50px -30px rgba(0,0,0,0.8)',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { opacity: '0.6' },
          '50%': { opacity: '1' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        riseIn: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        pulseGlow: 'pulseGlow 2.4s ease-in-out infinite',
        shimmer: 'shimmer 2.2s linear infinite',
        riseIn: 'riseIn 0.5s ease-out both',
      },
    },
  },
  plugins: [],
};
