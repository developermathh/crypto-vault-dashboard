export type Lang = 'es' | 'en' | 'pt';

export interface LangMeta {
  code: Lang;
  flag: string;
  name: string;
}

export const LANGUAGES: LangMeta[] = [
  { code: 'es', flag: '🇪🇸', name: 'Español' },
  { code: 'en', flag: '🇺🇸', name: 'English' },
  { code: 'pt', flag: '🇧🇷', name: 'Português' },
];

export interface Dict {
  // Header / nav
  nav: {
    prices: string;
    gasFees: string;
    support: string;
    code: string;
    subtitle: string;
  };
  hero: {
    badge: string;
    titlePre: string;
    titleHighlight: string;
    description: string;
  };
  monitor: {
    liveBadge: string;
    title: string;
    subtitle: string;
    searchPlaceholder: string;
    searchAria: string;
    clearAria: string;
    resultsCount: string;
    searching: string;
    noResults: string;
    noResultsHint: string;
    noConnection: string;
    updated: string;
    updatedAgo: (s: number) => string;
    top10: string;
    retrying: string;
    loadError: string;
    thRank: string;
    thAsset: string;
    thPrice: string;
    th24h: string;
    thMarketCap: string;
    thVolume: string;
    th7d: string;
    capShort: string;
  };
  gas: {
    badge: string;
    title: string;
    subtitle: string;
    txType: string;
    txTransfer: string;
    txSwap: string;
    txContract: string;
    speed: string;
    speedSlow: string;
    speedStandard: string;
    speedFast: string;
    speedSlowDesc: string;
    speedStandardDesc: string;
    speedFastDesc: string;
    gasPriceLabel: string;
    gasPriceOptional: string;
    gasLimitLabel: string;
    gasLimitOptional: string;
    estimateNote: string;
    estimatedCost: string;
    networkFee: string;
    usdEquivalent: string;
    gasLimit: string;
    gasPrice: string;
    bnbPrice: string;
    network: string;
  };
  support: {
    badge: string;
    title: string;
    description: string;
    walletLabel: string;
    usdtBep20: string;
    tether: string;
    copyBtn: string;
    copied: string;
    viewBscScan: string;
    copyError: string;
    beforeSending: string;
    check1: string;
    check2: string;
    check3: string;
  };
  footer: {
    rights: string;
    dataBy: string;
  };
}

export const TRANSLATIONS: Record<Lang, Dict> = {
  es: {
    nav: {
      prices: 'Precios',
      gasFees: 'Gas Fees',
      support: 'Soporte',
      code: 'Código',
      subtitle: 'Dashboard para inversores',
    },
    hero: {
      badge: 'Datos en vivo · CoinGecko',
      titlePre: 'Tu dashboard de análisis',
      titleHighlight: 'cripto',
      description:
        'Sigue el precio de las principales criptomonedas, estima el costo de tus transacciones en la BNB Smart Chain y apoya el proyecto con un aporte en USDT.',
    },
    monitor: {
      liveBadge: 'En tiempo real',
      title: 'Monitor de Precios',
      subtitle: 'Precios en vivo. Actualizado automáticamente cada 30s.',
      searchPlaceholder: 'Buscar cualquier criptomoneda...',
      searchAria: 'Buscar criptomoneda',
      clearAria: 'Limpiar búsqueda',
      resultsCount: (n: number) => `${n} resultado(s) para`,
      searching: 'Buscando...',
      noResults: 'No encontramos ninguna criptomoneda para',
      noResultsHint: 'Prueba con otro nombre o símbolo.',
      noConnection: 'Sin conexión — reintentando',
      updated: 'Actualizado',
      updatedAgo: (s: number) => {
        if (s < 5) return 'ahora mismo';
        if (s < 60) return `hace ${s}s`;
        return `hace ${Math.floor(s / 60)}min`;
      },
      top10: 'Top 10 por capitalización de mercado',
      retrying: 'No pudimos cargar los precios. Reintentaremos automáticamente.',
      loadError: 'No pudimos cargar los precios. Reintentaremos automáticamente.',
      thRank: '#',
      thAsset: 'Activo',
      thPrice: 'Precio',
      th24h: '24h %',
      thMarketCap: 'Cap. mercado',
      thVolume: 'Volumen 24h',
      th7d: '7 días',
      capShort: 'Cap.',
    },
    gas: {
      badge: 'BNB Smart Chain',
      title: 'Calculadora de Gas Fees',
      subtitle: 'Estima el costo de red de tus transacciones en la BNB Smart Chain (BEP-20).',
      txType: 'Tipo de transacción',
      txTransfer: 'Transferencia',
      txSwap: 'Swap (DEX)',
      txContract: 'Contrato',
      speed: 'Velocidad de red',
      speedSlow: 'Lento',
      speedStandard: 'Estándar',
      speedFast: 'Rápido',
      speedSlowDesc: '~5 min',
      speedStandardDesc: '~30 seg',
      speedFastDesc: '~10 seg',
      gasPriceLabel: 'Precio del Gas (Gwei)',
      gasPriceOptional: '— opcional',
      gasLimitLabel: 'Gas Limit (unidades)',
      gasLimitOptional: '— opcional',
      estimateNote:
        'Los valores son estimaciones basadas en condiciones típicas de la BNB Smart Chain. El costo real puede variar según la congestión de la red.',
      estimatedCost: 'Costo estimado',
      networkFee: 'Comisión de red (BNB)',
      usdEquivalent: 'Equivalente en USD',
      gasLimit: 'Gas Limit',
      gasPrice: 'Gas Price',
      bnbPrice: 'Precio BNB',
      network: 'Red',
    },
    support: {
      badge: 'Apoya el proyecto',
      title: 'Impulsa este proyecto ⚡',
      description:
        'Si esta plataforma aporta valor a tus análisis diarios, puedes respaldar su desarrollo e infraestructura. Tu apoyo impulsa directamente la optimización de nuestras herramientas Web3 y la expansión de nuestro ecosistema.',
      walletLabel: 'Dirección de billetera',
      usdtBep20: 'USDT · BEP-20',
      tether: 'Tether USD — BNB Smart Chain',
      copyBtn: 'Copiar dirección',
      copied: '¡Copiado!',
      viewBscScan: 'Ver en BscScan',
      copyError: 'No se pudo copiar automáticamente. Mantén presionada la dirección para copiarla manualmente.',
      beforeSending: 'Antes de enviar',
      check1: 'Verifica que la red seleccionada sea BNB Smart Chain (BEP-20).',
      check2: 'Asegúrate de tener BNB suficiente para cubrir el gas de la transferencia.',
      check3: 'Confirma la dirección completa antes de confirmar el envío.',
    },
    footer: {
      rights: 'Dashboard para inversores',
      dataBy: 'Datos por',
    },
  },
  en: {
    nav: {
      prices: 'Prices',
      gasFees: 'Gas Fees',
      support: 'Support',
      code: 'Code',
      subtitle: 'Investor Dashboard',
    },
    hero: {
      badge: 'Live data · CoinGecko',
      titlePre: 'Your crypto analysis',
      titleHighlight: 'dashboard',
      description:
        'Track the price of top cryptocurrencies, estimate your transaction costs on the BNB Smart Chain, and support the project with a USDT contribution.',
    },
    monitor: {
      liveBadge: 'Live',
      title: 'Price Monitor',
      subtitle: 'Live prices. Updated automatically every 30s.',
      searchPlaceholder: 'Search any cryptocurrency...',
      searchAria: 'Search cryptocurrency',
      clearAria: 'Clear search',
      resultsCount: (n: number) => `${n} result(s) for`,
      searching: 'Searching...',
      noResults: 'No cryptocurrency found for',
      noResultsHint: 'Try another name or symbol.',
      noConnection: 'No connection — retrying',
      updated: 'Updated',
      updatedAgo: (s: number) => {
        if (s < 5) return 'just now';
        if (s < 60) return `${s}s ago`;
        return `${Math.floor(s / 60)}min ago`;
      },
      top10: 'Top 10 by market capitalization',
      retrying: 'Could not load prices. Retrying automatically.',
      loadError: 'Could not load prices. Retrying automatically.',
      thRank: '#',
      thAsset: 'Asset',
      thPrice: 'Price',
      th24h: '24h %',
      thMarketCap: 'Market cap',
      thVolume: '24h volume',
      th7d: '7 days',
      capShort: 'Cap.',
    },
    gas: {
      badge: 'BNB Smart Chain',
      title: 'Gas Fee Calculator',
      subtitle: 'Estimate the network cost of your transactions on the BNB Smart Chain (BEP-20).',
      txType: 'Transaction type',
      txTransfer: 'Transfer',
      txSwap: 'Swap (DEX)',
      txContract: 'Contract',
      speed: 'Network speed',
      speedSlow: 'Slow',
      speedStandard: 'Standard',
      speedFast: 'Fast',
      speedSlowDesc: '~5 min',
      speedStandardDesc: '~30 sec',
      speedFastDesc: '~10 sec',
      gasPriceLabel: 'Gas Price (Gwei)',
      gasPriceOptional: '— optional',
      gasLimitLabel: 'Gas Limit (units)',
      gasLimitOptional: '— optional',
      estimateNote:
        'Values are estimates based on typical BNB Smart Chain conditions. Actual cost may vary depending on network congestion.',
      estimatedCost: 'Estimated cost',
      networkFee: 'Network fee (BNB)',
      usdEquivalent: 'USD equivalent',
      gasLimit: 'Gas Limit',
      gasPrice: 'Gas Price',
      bnbPrice: 'BNB price',
      network: 'Network',
    },
    support: {
      badge: 'Support the project',
      title: 'Boost this project ⚡',
      description:
        'If this platform brings value to your daily analysis, you can back its development and infrastructure. Your support directly drives the optimization of our Web3 tools and the expansion of our ecosystem.',
      walletLabel: 'Wallet address',
      usdtBep20: 'USDT · BEP-20',
      tether: 'Tether USD — BNB Smart Chain',
      copyBtn: 'Copy address',
      copied: 'Copied!',
      viewBscScan: 'View on BscScan',
      copyError: 'Could not copy automatically. Long-press the address to copy it manually.',
      beforeSending: 'Before sending',
      check1: 'Verify the selected network is BNB Smart Chain (BEP-20).',
      check2: 'Make sure you have enough BNB to cover the transfer gas fee.',
      check3: 'Confirm the full address before confirming the transaction.',
    },
    footer: {
      rights: 'Dashboard for investors',
      dataBy: 'Data by',
    },
  },
  pt: {
    nav: {
      prices: 'Preços',
      gasFees: 'Gas Fees',
      support: 'Apoio',
      code: 'Código',
      subtitle: 'Painel para investidores',
    },
    hero: {
      badge: 'Dados ao vivo · CoinGecko',
      titlePre: 'Seu painel de análise',
      titleHighlight: 'cripto',
      description:
        'Acompanhe o preço das principais criptomoedas, estime o custo das suas transações na BNB Smart Chain e apoie o projeto com uma contribuição em USDT.',
    },
    monitor: {
      liveBadge: 'Ao vivo',
      title: 'Monitor de Preços',
      subtitle: 'Preços ao vivo. Atualizado automaticamente a cada 30s.',
      searchPlaceholder: 'Buscar qualquer criptomoeda...',
      searchAria: 'Buscar criptomoeda',
      clearAria: 'Limpar busca',
      resultsCount: (n: number) => `${n} resultado(s) para`,
      searching: 'Buscando...',
      noResults: 'Nenhuma criptomoeda encontrada para',
      noResultsHint: 'Tente outro nome ou símbolo.',
      noConnection: 'Sem conexão — tentando novamente',
      updated: 'Atualizado',
      updatedAgo: (s: number) => {
        if (s < 5) return 'agora mesmo';
        if (s < 60) return `há ${s}s`;
        return `há ${Math.floor(s / 60)}min`;
      },
      top10: 'Top 10 por capitalização de mercado',
      retrying: 'Não foi possível carregar os preços. Tentando novamente automaticamente.',
      loadError: 'Não foi possível carregar os preços. Tentando novamente automaticamente.',
      thRank: '#',
      thAsset: 'Ativo',
      thPrice: 'Preço',
      th24h: '24h %',
      thMarketCap: 'Cap. mercado',
      thVolume: 'Volume 24h',
      th7d: '7 dias',
      capShort: 'Cap.',
    },
    gas: {
      badge: 'BNB Smart Chain',
      title: 'Calculadora de Gas Fees',
      subtitle: 'Estime o custo de rede das suas transações na BNB Smart Chain (BEP-20).',
      txType: 'Tipo de transação',
      txTransfer: 'Transferência',
      txSwap: 'Swap (DEX)',
      txContract: 'Contrato',
      speed: 'Velocidade da rede',
      speedSlow: 'Lento',
      speedStandard: 'Padrão',
      speedFast: 'Rápido',
      speedSlowDesc: '~5 min',
      speedStandardDesc: '~30 seg',
      speedFastDesc: '~10 seg',
      gasPriceLabel: 'Preço do Gas (Gwei)',
      gasPriceOptional: '— opcional',
      gasLimitLabel: 'Gas Limit (unidades)',
      gasLimitOptional: '— opcional',
      estimateNote:
        'Os valores são estimativas baseadas em condições típicas da BNB Smart Chain. O custo real pode variar dependendo da congestão da rede.',
      estimatedCost: 'Custo estimado',
      networkFee: 'Taxa de rede (BNB)',
      usdEquivalent: 'Equivalente em USD',
      gasLimit: 'Gas Limit',
      gasPrice: 'Gas Price',
      bnbPrice: 'Preço BNB',
      network: 'Rede',
    },
    support: {
      badge: 'Apoie o projeto',
      title: 'Impulsione este projeto ⚡',
      description:
        'Se esta plataforma agrega valor à sua análise diária, você pode apoiar seu desenvolvimento e infraestrutura. Seu apoio impulsiona diretamente a otimização de nossas ferramentas Web3 e a expansão do nosso ecossistema.',
      walletLabel: 'Endereço da carteira',
      usdtBep20: 'USDT · BEP-20',
      tether: 'Tether USD — BNB Smart Chain',
      copyBtn: 'Copiar endereço',
      copied: 'Copiado!',
      viewBscScan: 'Ver no BscScan',
      copyError: 'Não foi possível copiar automaticamente. Mantenha pressionado o endereço para copiá-lo manualmente.',
      beforeSending: 'Antes de enviar',
      check1: 'Verifique se a rede selecionada é BNB Smart Chain (BEP-20).',
      check2: 'Certifique-se de ter BNB suficiente para cobrir a taxa de gas da transferência.',
      check3: 'Confirme o endereço completo antes de confirmar o envio.',
    },
    footer: {
      rights: 'Painel para investidores',
      dataBy: 'Dados por',
    },
  },
};
