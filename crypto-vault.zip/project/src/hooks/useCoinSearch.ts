import { useCallback, useEffect, useRef, useState } from 'react';
import type { CoinState } from '@/types';

const API = 'https://api.coingecko.com/api/v3';

interface RawCoin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  price_change_percentage_24h: number;
  market_cap: number;
  market_cap_rank: number;
  total_volume: number;
  high_24h: number;
  low_24h: number;
  sparkline_in_7d?: { price: number[] };
  last_updated: string;
}

function toState(raw: RawCoin): CoinState {
  return {
    id: raw.id,
    symbol: raw.symbol?.toUpperCase() ?? '',
    name: raw.name ?? '',
    image: raw.image ?? '',
    price: raw.current_price ?? 0,
    change24h: raw.price_change_percentage_24h ?? 0,
    marketCap: raw.market_cap ?? 0,
    volume24h: raw.total_volume ?? 0,
    high24h: raw.high_24h ?? 0,
    low24h: raw.low_24h ?? 0,
    rank: raw.market_cap_rank ?? 0,
    sparkline: raw.sparkline_in_7d?.price ?? [],
    updatedAt: new Date(raw.last_updated).getTime(),
    previousPrice: raw.current_price ?? 0,
  };
}

export interface SearchResult {
  coin: CoinState;
  isExact: boolean;
}

export function useCoinSearch() {
  const [query, setQuery] = useState('');
  const [debounced, setDebounced] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reqId = useRef(0);

  // Debounce the raw query
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    const q = query.trim();
    if (!q) {
      setDebounced('');
      setResults([]);
      setError(null);
      return;
    }
    debounceRef.current = setTimeout(() => setDebounced(q), 500);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query]);

  // Run search when debounced query changes
  useEffect(() => {
    if (!debounced) {
      setResults([]);
      setSearching(false);
      return;
    }

    let cancelled = false;
    const currentReq = ++reqId.current;
    setSearching(true);
    setError(null);

    async function search() {
      try {
        // Step 1: search the CoinGecko /search endpoint for coin IDs
        const searchUrl = `${API}/search?query=${encodeURIComponent(debounced)}`;
        const searchRes = await fetch(searchUrl, {
          headers: { accept: 'application/json' },
        });
        if (!searchRes.ok) throw new Error(`HTTP ${searchRes.status}`);
        const searchData = (await searchRes.json()) as {
          coins: { id: string; name: string; symbol: string; market_cap_rank: number | null; thumb: string; large: string }[];
        };

        const matches = (searchData.coins ?? []).slice(0, 12);
        if (matches.length === 0) {
          if (!cancelled && currentReq === reqId.current) {
            setResults([]);
            setSearching(false);
          }
          return;
        }

        // Step 2: fetch market data for those coin IDs
        const ids = matches.map((m) => m.id).join(',');
        const marketUrl =
          `${API}/coins/markets?vs_currency=usd&ids=${ids}` +
          '&order=market_cap_desc&sparkline=true&price_change_percentage=24h&precision=full';

        const marketRes = await fetch(marketUrl, {
          headers: { accept: 'application/json' },
        });
        if (!marketRes.ok) throw new Error(`HTTP ${marketRes.status}`);
        const marketData = (await marketRes.json()) as RawCoin[];

        const lowerQ = debounced.toLowerCase();
        const sorted = marketData
          .map((raw) => {
            const coin = toState(raw);
            const isExact =
              coin.name.toLowerCase() === lowerQ ||
              coin.symbol.toLowerCase() === lowerQ;
            return { coin, isExact };
          })
          .sort((a, b) => {
            // exact matches first, then by market cap rank
            if (a.isExact !== b.isExact) return a.isExact ? -1 : 1;
            return (a.coin.rank || 999) - (b.coin.rank || 999);
          });

        if (!cancelled && currentReq === reqId.current) {
          setResults(sorted);
          setSearching(false);
        }
      } catch (e) {
        if (!cancelled && currentReq === reqId.current) {
          setError(e instanceof Error ? e.message : 'Error de búsqueda');
          setSearching(false);
        }
      }
    }

    void search();
    return () => {
      cancelled = true;
    };
  }, [debounced]);

  const clear = useCallback(() => {
    setQuery('');
    setDebounced('');
    setResults([]);
    setError(null);
  }, []);

  return { query, setQuery, results, searching, error, clear, hasQuery: debounced.length > 0 };
}
