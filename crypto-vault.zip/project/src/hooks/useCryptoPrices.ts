import { useEffect, useRef, useState } from 'react';
import { TOP_COIN_IDS, type CoinState } from '@/types';

const API = 'https://api.coingecko.com/api/v3';
const REFRESH_MS = 30_000;

interface RawCoin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  price_change_percentage_24h: number;
  market_cap: number;
  market_cap_rank: number;
  total_volume: number;
  high_24h: number;
  low_24h: number;
  sparkline_in_7d?: { price: number[] };
  last_updated: string;
}

function toState(raw: RawCoin, prev?: CoinState): CoinState {
  return {
    id: raw.id,
    symbol: raw.symbol?.toUpperCase() ?? '',
    name: raw.name ?? '',
    image: raw.image ?? '',
    price: raw.current_price ?? 0,
    change24h: raw.price_change_percentage_24h ?? 0,
    marketCap: raw.market_cap ?? 0,
    volume24h: raw.total_volume ?? 0,
    high24h: raw.high_24h ?? 0,
    low24h: raw.low_24h ?? 0,
    rank: raw.market_cap_rank ?? 0,
    sparkline: raw.sparkline_in_7d?.price ?? [],
    updatedAt: new Date(raw.last_updated).getTime(),
    previousPrice: prev ? prev.price : raw.current_price ?? 0,
  };
}

export function useCryptoPrices() {
  const [coins, setCoins] = useState<CoinState[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<number | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function fetchPrices() {
      const ids = TOP_COIN_IDS.join(',');
      const url =
        `${API}/coins/markets?vs_currency=usd&ids=${ids}` +
        '&order=market_cap_desc&sparkline=true&price_change_percentage=24h&precision=full';

      try {
        const res = await fetch(url, { headers: { accept: 'application/json' } });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as RawCoin[];

        setCoins((prev) => {
          const map = new Map(prev.map((p) => [p.id, p]));
          const order = new Map(TOP_COIN_IDS.map((id, i) => [id, i]));
          const next = data
            .map((raw) => toState(raw, map.get(raw.id)))
            .sort((a, b) => (order.get(a.id) ?? 99) - (order.get(b.id) ?? 99));
          return next;
        });
        if (!cancelled) {
          setError(null);
          setLoading(false);
          setLastUpdate(Date.now());
        }
      } catch (e) {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : 'Error de conexión');
          setLoading(false);
        }
      }
    }

    void fetchPrices();
    timer.current = setInterval(() => void fetchPrices(), REFRESH_MS);

    return () => {
      cancelled = true;
      if (timer.current) clearInterval(timer.current);
    };
  }, []);

  return { coins, loading, error, lastUpdate };
}
