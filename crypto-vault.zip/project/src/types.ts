export interface CoinMeta {
  id: string;
  symbol: string;
  name: string;
  color: string;
  icon: string;
}

export interface PriceTick {
  id: string;
  symbol: string;
  name: string;
  image: string;
  price: number;
  change24h: number;
  sparkline: number[];
  marketCap: number;
  volume24h: number;
  high24h: number;
  low24h: number;
  rank: number;
  updatedAt: number;
}

export interface CoinState extends PriceTick {
  previousPrice: number;
}

export const TOP_COIN_IDS = [
  'bitcoin',
  'ethereum',
  'binancecoin',
  'solana',
  'ripple',
  'cardano',
  'dogecoin',
  'tron',
  'polkadot',
  'litecoin',
];
