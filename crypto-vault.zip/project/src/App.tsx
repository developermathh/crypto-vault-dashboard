import { Github, LineChart } from 'lucide-react';
import { PriceMonitor } from '@/components/PriceMonitor';
import { GasCalculator } from '@/components/GasCalculator';
import { Donations } from '@/components/Donations';
import { LanguageSelector } from '@/components/LanguageSelector';
import { LanguageProvider, useLang } from '@/i18n/LanguageContext';
import { useCryptoPrices } from '@/hooks/useCryptoPrices';

function useBnbUsd(): number | undefined {
  const { coins } = useCryptoPrices();
  const bnb = coins.find((c) => c.id === 'binancecoin');
  return bnb ? bnb.price : undefined;
}

function AppContent() {
  const { t } = useLang();
  const bnbUsd = useBnbUsd();

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-ink-700/50 bg-ink-900/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3.5 sm:px-6">
          <a href="#top" className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-600 shadow-glow">
              <LineChart className="h-5 w-5 text-white" />
            </div>
            <div className="leading-tight">
              <p className="font-display text-base font-bold text-white">CryptoVault</p>
              <p className="text-[0.65rem] uppercase tracking-[0.2em] text-slate-500">
                {t.nav.subtitle}
              </p>
            </div>
          </a>
          <nav className="hidden items-center gap-1 sm:flex">
            <a href="#precios" className="rounded-lg px-3 py-2 text-sm font-medium text-slate-400 transition-colors hover:bg-ink-800 hover:text-white">
              {t.nav.prices}
            </a>
            <a href="#gas" className="rounded-lg px-3 py-2 text-sm font-medium text-slate-400 transition-colors hover:bg-ink-800 hover:text-white">
              {t.nav.gasFees}
            </a>
            <a href="#donaciones" className="rounded-lg px-3 py-2 text-sm font-medium text-slate-400 transition-colors hover:bg-ink-800 hover:text-white">
              {t.nav.support}
            </a>
          </nav>
          <div className="flex items-center gap-3">
            <LanguageSelector />
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost hidden sm:inline-flex"
            >
              <Github className="h-4 w-4" /> {t.nav.code}
            </a>
          </div>
        </div>
      </header>

      <main id="top" className="mx-auto max-w-6xl px-4 pb-20 pt-8 sm:px-6 sm:pt-12">
        {/* Hero */}
        <div className="mb-10 animate-riseIn sm:mb-14">
          <span className="chip bg-brand-400/10 text-brand-300">
            <span className="live-dot" /> {t.hero.badge}
          </span>
          <h1 className="mt-4 font-display text-3xl font-bold leading-tight text-white sm:text-5xl">
            {t.hero.titlePre}{' '}
            <span className="bg-gradient-to-r from-brand-300 via-brand-400 to-gold-400 bg-clip-text text-transparent">
              {t.hero.titleHighlight}
            </span>
          </h1>
          <p className="mt-3 max-w-2xl text-sm text-slate-400 sm:text-base">
            {t.hero.description}
          </p>
        </div>

        <div className="space-y-12 sm:space-y-16">
          <PriceMonitor />
          <GasCalculator bnbUsd={bnbUsd} />
          <Donations />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-ink-700/50 bg-ink-950/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-slate-500 sm:flex-row sm:px-6">
          <p>© {new Date().getFullYear()} CryptoVault · {t.footer.rights}</p>
          <p className="flex items-center gap-1.5">
            {t.footer.dataBy}
            <a
              href="https://www.coingecko.com"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-slate-400 underline-offset-2 hover:text-brand-300 hover:underline"
            >
              CoinGecko
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}

export default App;
