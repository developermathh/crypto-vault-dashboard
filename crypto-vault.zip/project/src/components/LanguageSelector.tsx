import { useLang } from '@/i18n/LanguageContext';
import { LANGUAGES } from '@/i18n/translations';

export function LanguageSelector() {
  const { lang, setLang } = useLang();

  return (
    <div className="flex items-center gap-1.5">
      {LANGUAGES.map((l) => {
        const active = lang === l.code;
        return (
          <button
            key={l.code}
            type="button"
            onClick={() => setLang(l.code)}
            aria-label={l.name}
            title={l.name}
            className={`flex h-8 w-8 items-center justify-center rounded-full text-base transition-all duration-200 ${
              active
                ? 'bg-brand-400/20 ring-2 ring-brand-400/50 scale-110'
                : 'bg-ink-800/60 ring-1 ring-ink-600 opacity-60 hover:opacity-100 hover:ring-ink-500'
            }`}
          >
            {l.flag}
          </button>
        );
      })}
    </div>
  );
}
