import { useMemo, useState } from 'react';
import { Calculator, Fuel, Zap, Info } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';

type TxType = 'transfer' | 'swap' | 'contract';
type Speed = 'slow' | 'standard' | 'fast';

const TX_GAS: Record<TxType, number> = {
  transfer: 21_000,
  swap: 150_000,
  contract: 200_000,
};

const SPEED_GWEI: Record<Speed, number> = {
  slow: 1,
  standard: 3,
  fast: 5,
};

const BNB_USD_FALLBACK = 600;

function formatUsd(n: number): string {
  return n.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 4,
    maximumFractionDigits: 4,
  });
}

function formatBnb(n: number): string {
  return n.toLocaleString('en-US', {
    minimumFractionDigits: 6,
    maximumFractionDigits: 6,
  });
}

interface GasCalculatorProps {
  bnbUsd?: number;
}

export function GasCalculator({ bnbUsd }: GasCalculatorProps) {
  const { t } = useLang();
  const [txType, setTxType] = useState<TxType>('transfer');
  const [speed, setSpeed] = useState<Speed>('standard');
  const [customGasPrice, setCustomGasPrice] = useState<string>('');
  const [customGasLimit, setCustomGasLimit] = useState<string>('');

  const priceUsd = bnbUsd ?? BNB_USD_FALLBACK;

  const txLabels: Record<TxType, string> = {
    transfer: t.gas.txTransfer,
    swap: t.gas.txSwap,
    contract: t.gas.txContract,
  };

  const speedLabels: Record<Speed, string> = {
    slow: t.gas.speedSlow,
    standard: t.gas.speedStandard,
    fast: t.gas.speedFast,
  };

  const speedDesc: Record<Speed, string> = {
    slow: t.gas.speedSlowDesc,
    standard: t.gas.speedStandardDesc,
    fast: t.gas.speedFastDesc,
  };

  const gasLimit = useMemo(() => {
    const v = parseInt(customGasLimit, 10);
    return Number.isFinite(v) && v > 0 ? v : TX_GAS[txType];
  }, [customGasLimit, txType]);

  const gasPriceGwei = useMemo(() => {
    const v = parseFloat(customGasPrice);
    return Number.isFinite(v) && v > 0 ? v : SPEED_GWEI[speed];
  }, [customGasPrice, speed]);

  const gasFeeBnb = useMemo(
    () => (gasLimit * gasPriceGwei) / 1e9,
    [gasLimit, gasPriceGwei]
  );
  const gasFeeUsd = useMemo(() => gasFeeBnb * priceUsd, [gasFeeBnb, priceUsd]);

  return (
    <section id="gas" aria-labelledby="gas-h">
      <header className="mb-5">
        <div className="flex items-center gap-2 text-gold-400">
          <Fuel className="h-4 w-4" />
          <span className="text-xs font-semibold uppercase tracking-[0.18em]">
            {t.gas.badge}
          </span>
        </div>
        <h2 id="gas-h" className="mt-2 font-display text-2xl font-bold text-white sm:text-3xl">
          {t.gas.title}
        </h2>
        <p className="mt-1 text-sm text-slate-400">{t.gas.subtitle}</p>
      </header>

      <div className="card overflow-hidden">
        <div className="grid lg:grid-cols-[1fr_1.1fr]">
          {/* Inputs */}
          <div className="space-y-5 border-b border-ink-700/60 p-5 sm:p-6 lg:border-b-0 lg:border-r">
            <div>
              <span className="field-label">{t.gas.txType}</span>
              <div className="grid grid-cols-3 gap-2">
                {(Object.keys(txLabels) as TxType[]).map((key) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      setTxType(key);
                      setCustomGasLimit('');
                    }}
                    className={`rounded-xl border px-2 py-2.5 text-xs font-semibold transition-all ${
                      txType === key
                        ? 'border-brand-400/50 bg-brand-400/10 text-white'
                        : 'border-ink-600 bg-ink-900/50 text-slate-400 hover:border-ink-500 hover:text-slate-200'
                    }`}
                  >
                    {txLabels[key]}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="field-label">{t.gas.speed}</span>
              <div className="grid grid-cols-3 gap-2">
                {(Object.keys(speedLabels) as Speed[]).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      setSpeed(s);
                      setCustomGasPrice('');
                    }}
                    className={`flex flex-col items-center gap-0.5 rounded-xl border px-2 py-2.5 transition-all ${
                      speed === s && !customGasPrice
                        ? 'border-brand-400/50 bg-brand-400/10 text-white'
                        : 'border-ink-600 bg-ink-900/50 text-slate-400 hover:border-ink-500 hover:text-slate-200'
                    }`}
                  >
                    <span className="text-xs font-semibold">{speedLabels[s]}</span>
                    <span className="text-[0.65rem] text-slate-500">{speedDesc[s]}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="gp" className="field-label">
                {t.gas.gasPriceLabel} {t.gas.gasPriceOptional}
              </label>
              <div className="relative">
                <input
                  id="gp"
                  type="number"
                  inputMode="decimal"
                  min="0"
                  step="0.1"
                  value={customGasPrice}
                  onChange={(e) => setCustomGasPrice(e.target.value)}
                  placeholder={SPEED_GWEI[speed].toString()}
                  className="field pr-14"
                />
                <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-500">
                  Gwei
                </span>
              </div>
            </div>

            <div>
              <label htmlFor="gl" className="field-label">
                {t.gas.gasLimitLabel} {t.gas.gasLimitOptional}
              </label>
              <input
                id="gl"
                type="number"
                inputMode="numeric"
                min="0"
                step="1000"
                value={customGasLimit}
                onChange={(e) => setCustomGasLimit(e.target.value)}
                placeholder={TX_GAS[txType].toLocaleString('en-US')}
                className="field"
              />
            </div>

            <p className="flex items-start gap-2 rounded-lg bg-ink-900/60 p-3 text-xs text-slate-500">
              <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              {t.gas.estimateNote}
            </p>
          </div>

          {/* Result */}
          <div className="relative flex flex-col justify-center bg-gradient-to-br from-ink-900/40 to-ink-850 p-5 sm:p-8">
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-gold-400/8 to-transparent" />
            <div className="relative">
              <div className="mb-4 flex items-center gap-2 text-slate-400">
                <Calculator className="h-4 w-4" />
                <span className="text-xs font-medium uppercase tracking-wider">
                  {t.gas.estimatedCost}
                </span>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="text-xs text-slate-500">{t.gas.networkFee}</p>
                  <p className="font-display text-3xl font-bold text-white sm:text-4xl">
                    {formatBnb(gasFeeBnb)}{' '}
                    <span className="text-lg font-semibold text-gold-400">BNB</span>
                  </p>
                </div>

                <div className="flex items-center gap-2 rounded-xl border border-ink-700/60 bg-ink-900/50 p-3">
                  <Zap className="h-4 w-4 text-brand-400" />
                  <div className="flex-1">
                    <p className="text-[0.7rem] uppercase tracking-wider text-slate-500">
                      {t.gas.usdEquivalent}
                    </p>
                    <p className="font-display text-xl font-bold text-brand-300">
                      {formatUsd(gasFeeUsd)}
                    </p>
                  </div>
                </div>

                <dl className="grid grid-cols-2 gap-3 pt-1 text-xs">
                  <div className="rounded-lg bg-ink-900/40 p-2.5">
                    <dt className="text-slate-500">{t.gas.gasLimit}</dt>
                    <dd className="font-semibold text-slate-200">
                      {gasLimit.toLocaleString('en-US')}
                    </dd>
                  </div>
                  <div className="rounded-lg bg-ink-900/40 p-2.5">
                    <dt className="text-slate-500">{t.gas.gasPrice}</dt>
                    <dd className="font-semibold text-slate-200">
                      {gasPriceGwei} Gwei
                    </dd>
                  </div>
                  <div className="rounded-lg bg-ink-900/40 p-2.5">
                    <dt className="text-slate-500">{t.gas.bnbPrice}</dt>
                    <dd className="font-semibold text-slate-200">
                      ${priceUsd.toFixed(2)}
                    </dd>
                  </div>
                  <div className="rounded-lg bg-ink-900/40 p-2.5">
                    <dt className="text-slate-500">{t.gas.network}</dt>
                    <dd className="font-semibold text-slate-200">BSC · BEP-20</dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
