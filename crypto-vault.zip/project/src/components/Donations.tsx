import { useEffect, useState } from 'react';
import { Zap, Copy, Check, ExternalLink } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';

const USDT_ADDRESS = '0x2D4E87686c4b2D1b53C95084616E6c4498575951';
const SHORT = `${USDT_ADDRESS.slice(0, 10)}…${USDT_ADDRESS.slice(-8)}`;

export function Donations() {
  const { t } = useLang();
  const [copied, setCopied] = useState(false);
  const [unsupported, setUnsupported] = useState(false);

  useEffect(() => {
    if (!copied) return;
    const timer = setTimeout(() => setCopied(false), 2200);
    return () => clearTimeout(timer);
  }, [copied]);

  async function copyAddress() {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(USDT_ADDRESS);
      } else {
        const el = document.createElement('textarea');
        el.value = USDT_ADDRESS;
        el.style.position = 'fixed';
        el.style.opacity = '0';
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      }
      setCopied(true);
    } catch {
      setUnsupported(true);
      setTimeout(() => setUnsupported(false), 2600);
    }
  }

  return (
    <section id="donaciones" aria-labelledby="don-h">
      <header className="mb-5">
        <div className="flex items-center gap-2 text-ok-400">
          <Zap className="h-4 w-4" />
          <span className="text-xs font-semibold uppercase tracking-[0.18em]">
            {t.support.badge}
          </span>
        </div>
        <h2 id="don-h" className="mt-2 font-display text-2xl font-bold text-white sm:text-3xl">
          {t.support.title}
        </h2>
        <p className="mt-1 max-w-2xl text-sm text-slate-400">
          {t.support.description}
        </p>
      </header>

      <div className="card overflow-hidden">
        <div className="relative grid gap-6 p-6 sm:p-8 md:grid-cols-[1.2fr_1fr] md:items-center">
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-ok-400/8 via-transparent to-brand-400/8" />
          <div className="relative">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-ok-400/20 to-brand-400/10 ring-1 ring-ok-400/30">
                <span className="font-display text-lg font-bold text-ok-400">₮</span>
              </div>
              <div>
                <p className="font-display text-lg font-semibold text-white">
                  {t.support.usdtBep20}
                </p>
                <p className="text-xs text-slate-400">
                  {t.support.tether}
                </p>
              </div>
            </div>

            <div className="mt-5">
              <span className="field-label">{t.support.walletLabel}</span>
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                <code className="flex-1 select-all break-all rounded-xl border border-ink-600 bg-ink-900/70 px-3.5 py-3 font-mono text-xs text-slate-200 sm:text-sm">
                  {USDT_ADDRESS}
                </code>
              </div>
              <p className="mt-2 font-mono text-xs text-slate-500 sm:hidden">{SHORT}</p>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={copyAddress}
                className={copied ? 'btn bg-ok-500/15 text-ok-400 ring-1 ring-ok-400/40' : 'btn-primary'}
              >
                {copied ? (
                  <>
                    <Check className="h-4 w-4" /> {t.support.copied}
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" /> {t.support.copyBtn}
                  </>
                )}
              </button>
              <a
                href={`https://bscscan.com/address/${USDT_ADDRESS}`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-ghost"
              >
                <ExternalLink className="h-4 w-4" /> {t.support.viewBscScan}
              </a>
            </div>

            {unsupported && (
              <p className="mt-3 text-xs text-gold-400">
                {t.support.copyError}
              </p>
            )}
          </div>

          <aside className="relative rounded-2xl border border-ink-700/60 bg-ink-900/50 p-5">
            <h3 className="font-display text-sm font-semibold text-white">
              {t.support.beforeSending}
            </h3>
            <ul className="mt-3 space-y-2.5 text-xs text-slate-400">
              <li className="flex gap-2">
                <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ok-400" />
                {t.support.check1}
              </li>
              <li className="flex gap-2">
                <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ok-400" />
                {t.support.check2}
              </li>
              <li className="flex gap-2">
                <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ok-400" />
                {t.support.check3}
              </li>
            </ul>
          </aside>
        </div>
      </div>
    </section>
  );
}
