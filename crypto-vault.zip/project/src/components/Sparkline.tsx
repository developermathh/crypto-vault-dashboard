import { useMemo } from 'react';

interface SparklineProps {
  data: number[];
  color: string;
  width?: number;
  height?: number;
  className?: string;
}

export function Sparkline({
  data,
  color,
  width = 120,
  height = 40,
  className,
}: SparklineProps) {
  const { path, area, last } = useMemo(() => {
    if (!data || data.length < 2) {
      return { path: '', area: '', last: { x: 0, y: 0 } };
    }
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;
    const stepX = width / (data.length - 1);
    const pad = 3;
    const usableH = height - pad * 2;

    const points = data.map((v, i) => {
      const x = i * stepX;
      const y = pad + (1 - (v - min) / range) * usableH;
      return { x, y };
    });

    const d = points
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(2)} ${p.y.toFixed(2)}`)
      .join(' ');
    const a = `${d} L ${width} ${height} L 0 ${height} Z`;
    return { path: d, area: a, last: points[points.length - 1] };
  }, [data, width, height]);

  if (!path) {
    return <div className={`skeleton ${className ?? ''}`} style={{ width, height }} />;
  }

  const gid = `spark-${color.replace('#', '')}`;
  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      preserveAspectRatio="none"
    >
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${gid})`} />
      <path
        d={path}
        fill="none"
        stroke={color}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx={last.x} cy={last.y} r="2.6" fill={color} />
    </svg>
  );
}
