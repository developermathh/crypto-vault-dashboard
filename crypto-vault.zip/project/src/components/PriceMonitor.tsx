import { useEffect, useState } from 'react';
import { TrendingUp, TrendingDown, Search, X, Loader2, Activity, WifiOff, Star } from 'lucide-react';
import { useCryptoPrices } from '@/hooks/useCryptoPrices';
import { useCoinSearch } from '@/hooks/useCoinSearch';
import { useLang } from '@/i18n/LanguageContext';
import { Sparkline } from './Sparkline';
import type { CoinState } from '@/types';

function formatUsd(n: number, digits = 2): string {
  if (n >= 1) {
    return n.toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }
  return n.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: digits,
    maximumFractionDigits: 6,
  });
}

function formatCompact(n: number): string {
  return n.toLocaleString('en-US', {
    notation: 'compact',
    maximumFractionDigits: 2,
  });
}

function CoinRow({ coin, index }: { coin: CoinState; index: number }) {
  const [flash, setFlash] = useState<'up' | 'down' | null>(null);

  useEffect(() => {
    if (coin.previousPrice === coin.price) return;
    setFlash(coin.price > coin.previousPrice ? 'up' : 'down');
    const t = setTimeout(() => setFlash(null), 700);
    return () => clearTimeout(t);
  }, [coin.price, coin.previousPrice]);

  const up = coin.change24h >= 0;
  const sparkColor = up ? '#34d399' : '#f87171';

  return (
    <tr className="group border-b border-ink-700/40 transition-colors hover:bg-ink-800/40">
      <td className="py-3.5 pl-3 pr-2 text-center text-xs font-medium text-slate-500 sm:pl-5">
        {coin.rank || index + 1}
      </td>
      <td className="py-3.5 pr-3">
        <div className="flex items-center gap-2.5">
          {coin.image ? (
            <img src={coin.image} alt={coin.name} loading="lazy" className="h-7 w-7 rounded-full" />
          ) : (
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-ink-700 text-xs font-bold text-slate-400">
              {coin.symbol.slice(0, 2)}
            </div>
          )}
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-white">{coin.name}</p>
            <p className="text-xs text-slate-500">{coin.symbol}</p>
          </div>
        </div>
      </td>
      <td
        className={`py-3.5 pr-3 text-right font-display text-sm font-bold transition-colors duration-500 ${
          flash === 'up' ? 'text-ok-400' : flash === 'down' ? 'text-bad-400' : 'text-white'
        }`}
      >
        {formatUsd(coin.price)}
      </td>
      <td className="hidden py-3.5 pr-3 text-right sm:table-cell">
        <span className={`chip ${up ? 'bg-ok-500/12 text-ok-400' : 'bg-bad-500/12 text-bad-400'}`}>
          {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
          {up ? '+' : ''}{coin.change24h.toFixed(2)}%
        </span>
      </td>
      <td className="hidden py-3.5 pr-3 text-right text-sm text-slate-300 lg:table-cell">
        ${formatCompact(coin.marketCap)}
      </td>
      <td className="hidden py-3.5 pr-3 text-right text-sm text-slate-300 lg:table-cell">
        ${formatCompact(coin.volume24h)}
      </td>
      <td className="hidden py-3.5 pr-3 text-right md:table-cell">
        <Sparkline data={coin.sparkline} color={sparkColor} width={90} height={32} />
      </td>
      <td className="py-3.5 pr-3 text-right sm:hidden">
        <span className={`text-xs font-semibold ${up ? 'text-ok-400' : 'text-bad-400'}`}>
          {up ? '+' : ''}{coin.change24h.toFixed(1)}%
        </span>
      </td>
    </tr>
  );
}

function CoinMobileCard({ coin, index }: { coin: CoinState; index: number }) {
  const up = coin.change24h >= 0;
  const sparkColor = up ? '#34d399' : '#f87171';

  return (
    <div className="card card-hover p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          {coin.image ? (
            <img src={coin.image} alt={coin.name} loading="lazy" className="h-8 w-8 rounded-full" />
          ) : (
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-ink-700 text-xs font-bold text-slate-400">
              {coin.symbol.slice(0, 2)}
            </div>
          )}
          <div>
            <p className="text-sm font-semibold text-white">{coin.name}</p>
            <p className="text-xs text-slate-500">{coin.symbol} · #{coin.rank || index + 1}</p>
          </div>
        </div>
        <Sparkline data={coin.sparkline} color={sparkColor} width={70} height={28} />
      </div>
      <div className="mt-3 flex items-end justify-between">
        <div>
          <p className="font-display text-lg font-bold text-white">{formatUsd(coin.price)}</p>
          <p className="text-xs text-slate-500">{formatCompact(coin.marketCap)}</p>
        </div>
        <span className={`chip ${up ? 'bg-ok-500/12 text-ok-400' : 'bg-bad-500/12 text-bad-400'}`}>
          {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
          {up ? '+' : ''}{coin.change24h.toFixed(2)}%
        </span>
      </div>
    </div>
  );
}

export function PriceMonitor() {
  const { t } = useLang();
  const { coins, loading, error, lastUpdate } = useCryptoPrices();
  const search = useCoinSearch();
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setTick((x) => x + 1), 10_000);
    return () => clearInterval(interval);
  }, []);
  void tick;

  const showSearch = search.hasQuery;
  const displayCoins = showSearch ? search.results.map((r) => r.coin) : coins;
  const showLoading = showSearch ? search.searching : loading;

  const agoStr = (() => {
    if (!lastUpdate) return '—';
    const s = Math.floor((Date.now() - lastUpdate) / 1000);
    return t.monitor.updatedAgo(s);
  })();

  return (
    <section id="precios" aria-labelledby="precios-h">
      <header className="mb-5">
        <div className="flex items-center gap-2 text-brand-400">
          <span className="live-dot" />
          <span className="text-xs font-semibold uppercase tracking-[0.18em]">
            {t.monitor.liveBadge}
          </span>
        </div>
        <h2 id="precios-h" className="mt-2 font-display text-2xl font-bold text-white sm:text-3xl">
          {t.monitor.title}
        </h2>
        <p className="mt-1 text-sm text-slate-400">{t.monitor.subtitle}</p>
      </header>

      {/* Search bar */}
      <div className="relative mb-5">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            inputMode="search"
            value={search.query}
            onChange={(e) => search.setQuery(e.target.value)}
            placeholder={t.monitor.searchPlaceholder}
            className="field pl-10 pr-10"
            aria-label={t.monitor.searchAria}
          />
          {search.query && (
            <button
              type="button"
              onClick={search.clear}
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-1 text-slate-500 transition-colors hover:bg-ink-700 hover:text-white"
              aria-label={t.monitor.clearAria}
            >
              <X className="h-4 w-4" />
            </button>
          )}
          {search.searching && (
            <Loader2 className="absolute right-9 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-brand-400" />
          )}
        </div>
        <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-slate-500">
            {showSearch ? (
              <span className="flex items-center gap-1.5 text-brand-300">
                <Star className="h-3.5 w-3.5" />
                {search.results.length > 0
                  ? `${t.monitor.resultsCount(search.results.length)} "${search.query}"`
                  : search.searching
                    ? t.monitor.searching
                    : `${t.monitor.noResults} "${search.query}"`}
              </span>
            ) : error ? (
              <span className="flex items-center gap-1.5 text-bad-400">
                <WifiOff className="h-3.5 w-3.5" /> {t.monitor.noConnection}
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-slate-500">
                <Activity className="h-3.5 w-3.5 text-ok-400" />
                {t.monitor.updated} {agoStr}
              </span>
            )}
          </div>
          {!showSearch && (
            <span className="text-slate-600">{t.monitor.top10}</span>
          )}
        </div>
      </div>

      {/* Content */}
      {showLoading && displayCoins.length === 0 ? (
        <div className="card overflow-hidden">
          <div className="space-y-3 p-5">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="skeleton h-7 w-7 rounded-full" />
                <div className="skeleton h-4 flex-1" />
                <div className="skeleton h-4 w-24" />
              </div>
            ))}
          </div>
        </div>
      ) : displayCoins.length === 0 && !showSearch ? (
        <div className="card flex flex-col items-center gap-3 p-10 text-center">
          <WifiOff className="h-6 w-6 text-slate-500" />
          <p className="text-sm text-slate-400">{t.monitor.loadError}</p>
        </div>
      ) : displayCoins.length === 0 && showSearch && !search.searching ? (
        <div className="card flex flex-col items-center gap-3 p-10 text-center">
          <Search className="h-6 w-6 text-slate-500" />
          <p className="text-sm text-slate-400">
            {t.monitor.noResults} "{search.query}".
          </p>
          <p className="text-xs text-slate-600">{t.monitor.noResultsHint}</p>
        </div>
      ) : (
        <>
          {/* Desktop table */}
          <div className="card hidden overflow-hidden sm:block">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-ink-700/60 text-left text-[0.7rem] uppercase tracking-wider text-slate-500">
                    <th className="py-3 pl-3 pr-2 text-center font-medium sm:pl-5">{t.monitor.thRank}</th>
                    <th className="py-3 pr-3 font-medium">{t.monitor.thAsset}</th>
                    <th className="py-3 pr-3 text-right font-medium">{t.monitor.thPrice}</th>
                    <th className="hidden py-3 pr-3 text-right font-medium sm:table-cell">{t.monitor.th24h}</th>
                    <th className="hidden py-3 pr-3 text-right font-medium lg:table-cell">{t.monitor.thMarketCap}</th>
                    <th className="hidden py-3 pr-3 text-right font-medium lg:table-cell">{t.monitor.thVolume}</th>
                    <th className="hidden py-3 pr-3 text-right font-medium md:table-cell">{t.monitor.th7d}</th>
                  </tr>
                </thead>
                <tbody>
                  {displayCoins.map((coin, i) => (
                    <CoinRow key={coin.id} coin={coin} index={i} />
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile cards */}
          <div className="grid gap-3 sm:hidden">
            {displayCoins.map((coin, i) => (
              <CoinMobileCard key={coin.id} coin={coin} index={i} />
            ))}
          </div>
        </>
      )}
    </section>
  );
}
