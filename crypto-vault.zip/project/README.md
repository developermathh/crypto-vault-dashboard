# 🪙 CryptoVault - Dashboard para Inversores

Un dashboard moderno y optimizado para el seguimiento y análisis de criptomonedas en tiempo real. Diseñado para inversores que buscan una interfaz limpia, rápida y funcional.

## 🚀 Características

* **Monitoreo en Tiempo Real:** Datos actualizados del mercado financiero.
* **Interfaz Profesional:** Diseño oscuro moderno (*Dark Mode*) optimizado para analistas.
* **Métricas Clave:** Visualización clara de precios, tarifas de gas y estadísticas esenciales.
* **Multilingüe:** Soporte nativo para cambio de idioma.

## 🛠️ Tecnologías Utilizadas

* **React** & **TypeScript** - Estructura y lógica de la aplicación.
* **Vite** - Entorno de desarrollo rápido y empaquetamiento optimizado.
* **Tailwind CSS** - Estilos modernos y diseño responsivo.
* **CoinGecko API** - Proveedor de datos del mercado cripto.

## 📦 Instalación y Uso Local

Si deseas ejecutar este proyecto en tu computadora, sigue estos pasos:

1. Clona este repositorio.
2. Instala las dependencias necesarias:
   ```bash
   npm install
   ```
3. Inicia el servidor de desarrollo local:
   ```bash
   npm run dev
   ```

---
Desarrollado con fines profesionales y de inversión.

